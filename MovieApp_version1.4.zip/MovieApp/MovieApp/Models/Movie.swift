//
//  Movie.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

enum Genre: String, CaseIterable, Hashable {
    case Action, Comedy, Drama, Thriller, Crime, SciFi, Horror, Mystery, Western, Biography, Adventure
}

enum OnAirStatus: String, CaseIterable {
    case Playing, ComingSoon = "Coming Soon", NotInThreater = "Not in theater", Popular
}

struct Movie: Identifiable, Equatable {
    var id: Int
    var title: String
    var genre: [Genre]
    var duration: String
    var description: String
    var poster: Image
    var cast: [Cast]
    var review: Double
    var numReviews: String
    var onAirStatus: OnAirStatus
    var castDate: Date
    
    static func convertStringToDate(_ str: String) -> Date {
        let dateFormatter = DateFormatter()
        // 29 October 2019 20:15:55
        dateFormatter.dateFormat = "dd MMM yyyy HH:mm:ss"
        return dateFormatter.date(from: str) ?? Date.now // Oct 29, 2019 at 7:15 PM
    } 
}

extension Movie {
    static let movies: [Movie] = [
        .init(id: 1, title: "A million ways to die in the west", genre: [.Comedy, .Western], duration: "1h 56m",
              description: "As a cowardly farmer begins to fall for the mysterious new woman in town, he must put his newly found courage to the test when her husband, a notorious gun-slinger, announces his arrival.",
              poster: Images.movie1,
              cast: Cast.west,
              review: 6.1, numReviews: "192K", onAirStatus: .Popular, castDate: convertStringToDate("29 January 2023 03:05:00")),
        
        .init(id: 2,title: "Black Adam", genre: [.Action, .Thriller], duration: "2h 5m",
              description: "Nearly 5,000 years after he was bestowed with the almighty powers of the Egyptian gods--and imprisoned just as quickly--Black Adam is freed from his earthly tomb, ready to unleash his unique form of justice on the modern world.",
              poster: Images.movie2,
              cast: Cast.adam,
              review: 6.4, numReviews: "214K", onAirStatus: .Popular, castDate: convertStringToDate("29 January 2023 03:05:00")),
        
        .init(id: 3, title: "Black Panther: Wakanda Forever", genre: [.Action], duration: "2h 41m", description: "The people of Wakanda fight to protect their home from intervening world powers as they mourn the death of King T'Challa.", poster: Images.movie3,
              cast: Cast.panther,
              review: 7.2, numReviews: "192K", onAirStatus: .ComingSoon, castDate: convertStringToDate("29 March 2023 03:05:00")),
    
        .init(id: 4, title: "Edge of tomorrow", genre: [.Action, .Mystery], duration: "1h 53m",
              description: "A soldier fighting aliens gets to relive the same day over and over again, the day restarting every time he dies.",
              poster: Images.movie4,
              cast: Cast.edge,
              review: 7.9, numReviews: "685K", onAirStatus: .Popular, castDate: convertStringToDate("29 January 2023 03:05:00")),
        
        .init(id: 5, title: "The Hangover Part ||", genre: [.Comedy], duration: "1h 42m",
              description: "Two years after the bachelor party in Las Vegas, Phil, Stu, Alan, and Doug jet to Thailand for Stu's wedding. Stu's plan for a subdued pre-wedding brunch, however, goes seriously awry.",
              poster: Images.movie5,
              cast: Cast.hangover,
              review: 6.5, numReviews: "505K", onAirStatus: .Playing, castDate: convertStringToDate("29 January 2023 03:05:00")),
        
        .init(id: 6, title: "Jaws", genre: [.Horror], duration: "2h 4m", description: "When a killer shark unleashes chaos on a beach community off Cape Cod, it's up to a local sheriff, a marine biologist, and an old seafarer to hunt the beast down.", poster: Images.movie6,
              cast: Cast.jaws,
              review: 8.1, numReviews: "612K", onAirStatus: .Playing, castDate: convertStringToDate("29 January 2023 03:05:00")),
    
        .init(id: 7, title: "Joker", genre: [.Action, .Crime], duration: "2h 2m", description: "A mentally troubled stand-up comedian embarks on a downward spiral that leads to the creation of an iconic villain.", poster: Images.movie7,
              cast: Cast.joker,
              review: 8.4, numReviews: "1.3M", onAirStatus: .Popular, castDate: convertStringToDate("29 January 2023 03:05:00")),
    
        .init(id: 8, title: "Sully", genre: [.Biography, .Drama], duration: "1h 36m", description: "When pilot Chesley 'Sully' Sullenberger lands his damaged plane on the Hudson River in order to save the flight's passengers and crew, some consider him a hero while others think he was reckless.",
              poster: Images.movie8,
              cast: Cast.sully,
              review: 7.4, numReviews: "277K", onAirStatus: .Playing, castDate: convertStringToDate("29 January 2023 03:05:00")),
    
        .init(id: 9, title: "The Man From Uncle", genre: [.Action, .Comedy, .Crime], duration: "1h 56m", description: "In the early 1960s, CIA agent Napoleon Solo and KGB operative Illya Kuryakin participate in a joint mission against a mysterious criminal organization, which is working to proliferate nuclear weapons.", poster: Images.movie9,
              cast: Cast.uncle,
              review: 7.2, numReviews: "314K", onAirStatus: .ComingSoon, castDate: convertStringToDate("29 March 2023 03:05:00")),
    
        .init(id: 10, title: "The Lord of The Rings: The Two Towers", genre: [.Action, .Adventure, .Drama], duration: "2h 59m", description: "While Frodo and Sam edge closer to Mordor with the help of the shifty Gollum, the divided fellowship makes a stand against Sauron's new ally, Saruman, and his hordes of Isengard.", poster: Images.movie10, cast:
                Cast.rings,
              review: 8.8, numReviews: "1.7M", onAirStatus: .ComingSoon, castDate: convertStringToDate("29 March 2023 03:05:00")),
    
        .init(id: 11, title: "The Meg", genre: [.Action, .SciFi, .Horror], duration: "1h 53m",
          description: "Cryptonight", poster: Images.movie11,
              cast: Cast.meg,
              review: 5.6, numReviews: "174K", onAirStatus: .ComingSoon, castDate: convertStringToDate("29 March 2023 03:05:00"))
    ]
}

