//
//  User.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct User: Identifiable {
    var id: Int
    var name: String
    var email: String
    var password: String
    var image: Image
    var favorites: [Int] = []
   
    init(id: Int, name: String, email: String, password: String, image: Image) {
        self.id = id
        self.name = name
        self.email = email
        self.password = password
        self.image = image
    }
    
    static var user = User(id: 1, name: "John", email: "john@example.com", password: "password", image: Images.logo)
}
