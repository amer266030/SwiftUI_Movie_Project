//
//  Cast.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct Cast: Hashable {
    var name: String
    var image: Image
    
    func hash(into hasher: inout Hasher) {
            hasher.combine(name)
    }
    
    static var west: [Cast] = [
         Cast(name: "Seth MacFarlane", image: Images.seth),
         Cast(name: "Charlize Theron", image: Images.charlize),
         Cast(name: "Liam Neeson", image: Images.liam)
    ]
    
    static var adam: [Cast] = [
        Cast(name: "Dwayne Johnson", image: Images.dwayn),
        Cast(name: "Pierce Brosnan", image: Images.pierce),
        Cast(name: "Aldis Hodge", image: Images.aldis)
    ]
    
    static var panther: [Cast] = [
        Cast(name: "Letitia Wright", image: Images.letitia),
        Cast(name: "Lupita Nyong'o", image: Images.lupita),
        Cast(name: "Danai Gurira", image: Images.dania)
    ]
    
    static var edge: [Cast] = [
        Cast(name: "Tom Cruise", image: Images.cruise),
        Cast(name: "Emily Blunt", image: Images.blunt)
    ]
    
    static var hangover: [Cast] = [
        Cast(name: "Bradley Cooper", image: Images.bradley),
        Cast(name: "Zach Galifianakis", image: Images.zack),
        Cast(name: "Ed Helms", image: Images.ed)
    ]
    
    static var jaws: [Cast] = [
        Cast(name: "Roy Scheider", image: Images.roy),
        Cast(name: "Robert Shaw", image: Images.shaw)
    ]
    
    static var joker: [Cast] = [
        Cast(name: "Joaquin Phoenix", image: Images.joaquin),
        Cast(name: "Robert De Niro", image: Images.deniro)
    ]
    
    static var sully: [Cast] = [
        Cast(name: "Tom Hanks", image: Images.hanks),
        Cast(name: "Laura Linney", image: Images.laura)
    ]
    
    static var uncle: [Cast] = [
        Cast(name: "Henry Cavill", image: Images.henry),
        Cast(name: "Armie Hammer", image: Images.hammer),
        Cast(name: "Alicia Vikander", image: Images.alicia)
    ]
    
    static var rings: [Cast] = [
        Cast(name: "Elijah Wood", image: Images.logo),
        Cast(name: "Ian McKellen", image: Images.logo)
    ]
    
    static var meg: [Cast] = [
        Cast(name: "Jason Statham", image: Images.statham),
        Cast(name: "Bingbing Li", image: Images.binbing)
    ]
}


