//
//  FovoritesView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct FavoriteView: View {
    
    @State private var isInFavorites: [Int] = UserDefaults.standard.object(forKey: "favorites") as? [Int] ?? []
    let movies = Movie.movies
    
    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .ignoresSafeArea(.all, edges: .top)
            VStack {
                // MARK: - Title
                VStack {
                    Text(favoritesK)
                        .foregroundColor(Color.primary)
                        .font(.largeTitle)
                        .padding()
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                }
                VStack {
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack {
                            ForEach(isInFavorites, id: \.self) { fav in
                                if let movie = movies.first(where: {$0.id == fav}) {
                                    HStack {
                                        HStack {
                                            NavigationLink(destination: MovieDetailsView(movie: movie).navigationBarBackButtonHidden(true)) {
                                                movie.poster
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(width: UIScreen.main.bounds.width/3)
                                                    .cornerRadius(24)
                                            }
                                            
                                            Spacer()
                                        }
                                        
                                        VStack(alignment: .center) {
                                            Text(movie.title)
                                                .foregroundColor(.primary)
                                                .padding()
                                            
                                            ShareLink(item: movie.poster, preview: SharePreview(movie.title, image: movie.poster))
                                        }
                                        
                                    }
                                    .padding()
                                    Divider()
                                }
                            }
                        }
                        .listRowBackground(Color.clear)
                        .ignoresSafeArea()
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                    .shadow(color: .secondary, radius: 5, x: 5, y: 5)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                }
            }
            .padding()
        }
        .onAppear {
            isInFavorites = UserDefaults.standard.object(forKey: "favorites") as? [Int] ?? []
        }
    }
}

//struct FovoritesView_Previews: PreviewProvider {
//    static var previews: some View {
//        FavoriteView()
//    }
//}
