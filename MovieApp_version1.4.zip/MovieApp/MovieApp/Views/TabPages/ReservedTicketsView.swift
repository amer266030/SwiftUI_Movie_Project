//
//  ReservedTicketsView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct ReservedTicketsView: View {
    
    @State private var isBooked: [Int: Int] = UserDefaults.standard.object([Int: Int].self, with: "booked") ?? [:]
    @State private var showingSheet = false
    @State private var BookedMovies:[(Movie, Seat)] = []
    let movies = Movie.movies
    var seats = Seat.seats
    
    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .ignoresSafeArea(.all, edges: .top)
            VStack {
                // MARK: - Title
                VStack {
                    Text(bookedTicketsK)
                        .foregroundColor(Color.primary)
                        .font(.largeTitle)
                        .padding()
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                }
                VStack {
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack {
                            ForEach(BookedMovies, id: \.0.id) { booked in
                                HStack {
                                    NavigationLink(destination: MovieDetailsView(movie: booked.0).navigationBarBackButtonHidden(true)) {
                                        booked.0.poster
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: UIScreen.main.bounds.width/3)
                                            .cornerRadius(24)
                                    }
                                    
                                    Spacer()
                                    
                                    VStack {
                                        Text(booked.0.title)
                                            .foregroundColor(.primary)
                                            .padding()
                                        
                                        HStack {
                                            VStack {
                                                // Booking Confirmation
                                                Button {
                                                    showingSheet.toggle()
                                                } label: {
                                                    Image(systemName: "ticket")
                                                        .font(.title)
                                                        .foregroundColor(.blue)
                                                }.sheet(isPresented: $showingSheet) {
                                                    BookingConfirmationView(movie: booked.0, seat: booked.1)
                                                }
                                                Text(viewTicketK)
                                                    .foregroundColor(.secondary)
                                                    .font(.caption)
                                            }
                                            
                                            // Edit Booking
                                            NavigationLink(destination: BookingPage(movie: booked.0).navigationBarBackButtonHidden(true)) {
                                                VStack {
                                                    Image(systemName: "chair.lounge.fill")
                                                        .font(.title)
                                                        .foregroundColor(.green)
                                                    
                                                    Text("Change Seats")
                                                        .foregroundColor(.secondary)
                                                        .font(.caption)
                                                }
                                            }
                                             
                                            VStack {
                                                Button {
                                                    isBooked.removeValue(forKey: booked.0.id)
                                                    UserDefaults.standard.set(object: isBooked, forKey: "booked")
                                                    BookedMovies = []
                                                    isBooked = UserDefaults.standard.object([Int: Int].self, with: "booked") ?? [:]
                                                    for item in isBooked {
                                                        if let movie = movies.first(where: {$0.id == item.key}) {
                                                            if let seat = seats.first(where: {$0.id == item.value}) {
                                                                BookedMovies.append((movie,seat))
                                                            }
                                                        }
                                                    }
                                                } label: {
                                                    Image(systemName: "xmark")
                                                        .font(.title)
                                                        .foregroundColor(.red)
                                                }
                                                
                                                Text("Cancel Booking")
                                                    .foregroundColor(.secondary)
                                                    .font(.caption)
                                            }
                                             
                                        }
                                    }
                                }
                                .padding()
                                
                                Divider()
                            }
                        }
                        .listRowBackground(Color.clear)
                        .ignoresSafeArea()
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                    .shadow(color: .secondary, radius: 5, x: 5, y: 5)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                }
            }
            .padding()
        }
        .onAppear {
            BookedMovies = []
            isBooked = UserDefaults.standard.object([Int: Int].self, with: "booked") ?? [:]
            for item in isBooked {
                if let movie = movies.first(where: {$0.id == item.key}) {
                    if let seat = seats.first(where: {$0.id == item.value}) {
                        BookedMovies.append((movie,seat))
                    }
                }
            }
        }
    }
}

//struct ReservedTicketsView_Previews: PreviewProvider {
//    static var previews: some View {
//        ReservedTicketsView()
//    }
//}
