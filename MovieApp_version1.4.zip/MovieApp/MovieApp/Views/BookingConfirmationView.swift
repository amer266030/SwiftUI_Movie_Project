//
//  BookingConfirmationView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import SwiftUI
import CoreImage.CIFilterBuiltins

struct BookingConfirmationView: View {
    @Environment(\.dismiss) var dismiss
    var movie: Movie
    var seat: Seat
    
    let context = CIContext()
    let filter = CIFilter.qrCodeGenerator()
    
    var body: some View {
        VStack {
            HStack {
                Button("Dismiss") {
                    dismiss()
                }
                .font(.title)
                .padding()
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                
                Spacer()
                Images.logo
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80)
            }
            .padding()
            ZStack {
                // MARK: - Background
                VStack {
                    movie.poster
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    Spacer()
                }
                
                VStack {
                    Spacer()
                    HStack {
                        Text("Booking Confirmed")
                            .foregroundColor(.primary)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                    }
                    HStack {
                        VStack {
                            Text("You can view your Ticket in the Tickets Page")
                                .foregroundColor(.secondary)
                                .font(.title3)
                                .bold()
                                .padding()
                            Text("SE YOU SOON!")
                                .foregroundColor(.secondary)
                                .font(.title3)
                                .bold()
                                .padding()
                        }
                    }
                    HStack {
                        Text("MOVIE:")
                            .foregroundColor(.primary)
                            .font(.title3)
                            .bold()
                            .padding([.leading, .vertical])
                    
                        Text(movie.title)
                            .foregroundColor(.primary)
                            .font(.body)
                            .padding([.trailing, .vertical])
                            .lineLimit(1)
                    }
                    HStack {
                        Text("$\(seat.price) Paid")
                            .foregroundColor(.primary)
                            .font(.title3)
                            .bold()
                            .padding()
                        
                        Spacer()
                        
                        Text("Seat Number: E\(seat.id)")
                            .foregroundColor(.primary)
                            .font(.title3)
                            .bold()
                            .padding()
                    }
                    Image(uiImage: generateQRCode(from: "Movie: \(movie.title)\n Seat Number: E\(seat.id), Date: \(movie.castDate) "))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .padding()
                }
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .padding()
            }
            .cornerRadius(24)
            .padding()
        }
    }
    
    func generateQRCode(from string: String) -> UIImage {
        filter.message = Data(string.utf8)

        if let outputImage = filter.outputImage {
            if let cgimg = context.createCGImage(outputImage, from: outputImage.extent) {
                return UIImage(cgImage: cgimg)
            }
        }

        return UIImage(systemName: "xmark.circle") ?? UIImage()
    }
    
}

struct BookingConfirmationView_Previews: PreviewProvider {
    static var previews: some View {
        BookingConfirmationView(movie: Movie.movies.first!, seat: Seat.seats.first!)
    }
}
