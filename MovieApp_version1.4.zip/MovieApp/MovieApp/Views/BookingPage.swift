//
//  BookingPage.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct BookingPage: View {
    
    @State private var selectedSeatId: Int = -1
    @State private var selectedSeat: Seat?
    var seats = Seat.seats
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var isBooked: [Int: Int] = UserDefaults.standard.object([Int: Int].self, with: "booked") ?? [:]
    @State private var showingSheet = false
    
    var movie: Movie
    
    var body: some View {
        ZStack{
            VStack(spacing: 16) {
                ZStack {
                    // MARK: - Seats Image
                    VStack {
                        Image(systemName: "tv")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .padding()
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 5), spacing: 15) {
                                ForEach(seats) { seat in
                                    Button {
                                        if !seat.reserved {
                                            selectedSeatId = seat.id
                                            selectedSeat = seat
                                        }
                                    } label: {
                                        if seat.reserved {
                                            seat.image
                                                .font(.largeTitle)
                                                .foregroundColor(.purple)
                                        } else {
                                            seat.image
                                                .font(.largeTitle)
                                                .foregroundColor(selectedSeatId == seat.id ? .green : .gray)
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal)
                    }
                    .padding()
                }
                .background(.black)
                .cornerRadius(24)
                
                // MARK: Seat Key
                HStack(spacing: 16) {
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.purple)
                        Text("Reserved")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.green)
                        Text("Selected")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.gray)
                        Text("Availble")
                    }
                }
                .padding()
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack{
                        HStack {
                            Text("Selected Seat:")
                                .foregroundColor(.primary)
                                .font(.title3)
                                .padding()
                            Text(selectedSeat == nil ? "None" : "E\(selectedSeat!.id)")
                                .font(.body)
                                .foregroundColor(selectedSeat == nil ? .secondary : .green)
                                .padding()
                        }
                        .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                        
                        HStack{
                            Text("Total:")
                                .font(.title3)
                                .foregroundColor(.primary)
                                .padding()
                            Text(selectedSeat == nil ? "$0" : "$\(selectedSeat!.price)")
                                .font(.body)
                                .foregroundColor(selectedSeat == nil ? .secondary : .green)
                                .padding()
                        }
                    }
                        
                }
                .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                
                HStack{
                    VStack{
                        Text(movie.castDate, style: .date)
                            .padding(.horizontal)
                            .padding(.top)
                        HStack {
                            Text("Time:")
                            Text("03:05 pm")
                        }
                        .foregroundColor(.primary)
                        .font(.body)
                        .padding()
                        
                    }
                    .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                    VStack {
                        Text("Movie: \(movie.title)")
                            .font(.body)
                            .bold()
                            .foregroundColor(.primary)
                            .lineLimit(3, reservesSpace: true)
                            .padding()
                    }
                    .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                }
                .padding()

                HStack{
                    Button{
                        presentationMode.wrappedValue.dismiss()
                    }label: {
                        Text("Cancel")
                            .font(.title)
                            .foregroundColor(.white)
                            .bold()
                            .padding()
                    }
                    .background(.blue)
                    .cornerRadius(16)
                    
                    Button{
                        // MARK: - Update Userdefaults
                        var myDic = isBooked
                        myDic[movie.id] = selectedSeatId
                    // Keu is Movie ID, Value is Seat ID
                        isBooked = myDic
                        UserDefaults.standard.set(object: isBooked, forKey: "booked")
                        showingSheet.toggle()
                        
                        if let date = Calendar.current.date(byAdding: .hour, value: -5, to: movie.castDate) {
                            let notify = NotificationHandler()
                            notify.sendNotification(
                            date: date,
                            type: "date",
                            title: "\(movie.title) is starting in 5 hours",
                            body: "Don't forget to get some PopCorn!")
                        }
                    } label: {
                        Text("Buy Ticket")
                            .font(.title)
                            .foregroundColor(.white)
                            .bold()
                            .padding()
                    }
                    .background(selectedSeat == nil ? Color.secondary : Color.green)
                    .cornerRadius(16)
                    .disabled(selectedSeat == nil ? true : false)
                    .sheet(isPresented: $showingSheet) {
                        BookingConfirmationView(movie: movie, seat: selectedSeat!)
                    }
                }
                .padding()
            }
            .padding()
        }
    }
}

struct BookingPage_Previews: PreviewProvider {
    static var previews: some View {
        BookingPage(movie: Movie.movies.first!)
    }
}
