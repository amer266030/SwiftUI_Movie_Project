//
//  OBPageView.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct OBPageView: View {
    let title: String
    let subtitle: String
    let imageName: String
    let showsDismissButton: Bool
    @Binding var shouldShowOnboarding: Bool
    
    var body: some View {
        VStack {
            Image(systemName: imageName)
                .resizable()
                .aspectRatio (contentMode: .fit)
                .frame(width: 150, height: 150)
                .padding()
            Text(title)
                .font(.system (size: 32))
                .padding()
            Text (subtitle)
                .font(.system (size: 24))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(.secondaryLabel))
                .padding()
            if showsDismissButton {
                Button(action: {
                    shouldShowOnboarding.toggle()
                    @AppStorage("shouldShowOnboarding") var shouldShowOnboarding = false
                }, label: {
                    Text("Get Started")
                        .shadow(color: .black, radius: 5, x: 2, y: 2)
                        .bold()
                        .foregroundColor(Color.white)
                        .frame(width: 200, height: 50)
                        .background (.ultraThickMaterial)
                        .cornerRadius (6)
                        
                })
                .shadow(color: .secondary, radius:5, x: 5, y:5)
            }
        }
    }
}

//struct OBPageView_Previews: PreviewProvider {
//    static var previews: some View {
//        OBPageView()
//    }
//}
