//
//  Onboarding1.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct OnboardingView: View {
    @Binding var shouldShowOnboarding: Bool
    var body: some View {
        TabView {
            OBPageView(
                title: "Popcorn Movies",
                subtitle: "Welcome to the Popcorn Movie App",
                imageName: "popcorn",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Search",
                subtitle: "Look up your Favorite movies",
                imageName: "magnifyingglass",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Favorites",
                subtitle: "Tag your favorites to book at your convenience",
                imageName: "heart",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Notifications",
                subtitle: "Set up reminders for your booked movies",
                imageName: "bell.and.waves.left.and.right",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Enjoy",
                subtitle: "And don't forget to get some Popcorn!",
                imageName: "popcorn",
                showsDismissButton: true,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
        }
        .tabViewStyle(PageTabViewStyle())
        
    }
}
