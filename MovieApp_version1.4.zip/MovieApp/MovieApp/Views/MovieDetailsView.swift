//
//  MovieDetailsView.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI
import YouTubePlayerKit

struct MovieDetailsView: View {
    
    @State private var isInFavorites: [Int] = UserDefaults.standard.object(forKey: "favorites") as? [Int] ?? []
    @State var isPresented = false
    @State var animationHeart = false
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var movie: Movie
    
    var body: some View {
        ZStack{
            VStack {
                ZStack{
                    // MARK: - Poster
                    VStack {
                        movie.poster
                            .resizable()
                            .frame(maxHeight: UIScreen.main.bounds.height/2)
                            .cornerRadius(48)
                            .ignoresSafeArea(.all , edges: .top)
                            .blur(radius: 3)
                        Spacer()
                    }
                    // MARK: - Top Buttons
                    VStack {
                        HStack{
                            Button{
                                self.presentationMode.wrappedValue.dismiss()
                            }label: {
                                Image(systemName: "x.circle")
                                    .font(.title)
                                    .foregroundColor(.red)
                                    .padding(4)
                                    .background(.regularMaterial , in: Circle())
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(.white , lineWidth: 1)
                                    }
                                Spacer()
                                HStack {
                                    Image(systemName: "clock")
                                        .font(.title3)
                                        .foregroundColor(.orange)
                                        .padding(5)
                                    
                                    Text(movie.duration)
                                        .font(.title2)
                                        .foregroundColor(.orange)
                                        .padding(5)
                                    
                                }
                                .background(.regularMaterial , in: RoundedRectangle(cornerRadius: 20))
                                    .overlay{
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(.orange , lineWidth: 1)
                                    }
                            }
                        }.padding()
                        Spacer()
                    }
                    // MARK: - Movie Details
                    VStack {
                        // MARK: - Title
                        Text(movie.title)
                            .font(.largeTitle)
                            .foregroundColor(.primary)
                            .bold()
                            .padding()
                            .multilineTextAlignment(.center)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        // MARK: - Reviews
                        HStack(spacing: 10) {
                            HStack {
                                Image(systemName: "star.fill")
                                    .font(.title3)
                                    .foregroundColor(.yellow)
                                Text("\(movie.review.removeZerosFromEnd())")
                                Text("(\(movie.numReviews)) reviews")
                            }
                            .padding()
                            
                            Spacer()
                            
                            HStack {
                                VStack {
                                    Button{
                                        isPresented = true
                                    }label: {
                                        VStack{
                                            Image(systemName: "video")
                                                .foregroundColor(.blue)
                                                .font(.title)
                                                .padding(.bottom, 3)
                                            
                                            Text("Play Trailer")
                                                .font(.caption)
                                        }
                                    }.sheet(isPresented: $isPresented) {
                                        YoutubeView(isPresented: $isPresented, youTubePlayer: "https://www.youtube.com/watch?v=CXxqG4aqwY4")
                                    }
                                }
                            }
                            .padding()
                        }
                        .font(.title3)
                        .foregroundColor(.primary)
                        .bold()
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        .padding(.horizontal)
                        
                        // MARK: - Genre
                        HStack {
                            Text("Genre:")
                                .foregroundColor(.primary)
                                .font(.title3)
                                .bold()
                                .padding()
                            
                            ScrollView(.horizontal) {
                                HStack {
                                    ForEach(movie.genre, id: \.self) { genre in
                                        Text(genre.rawValue)
                                            .foregroundColor(.black)
                                            .padding(8)
                                            .background(.orange, in: Capsule())
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        .padding()
                        // MARK: - Cast
                        HStack {
                            Text("Cast:")
                                .foregroundColor(.primary)
                                .font(.title3)
                                .bold()
                                .padding()
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(movie.cast, id: \.self) { cast in
                                        VStack {
                                            cast.image
                                                .resizable()
                                                .aspectRatio(1, contentMode: .fit)
                                                .frame(width:60)
                                            
                                            Text(cast.name)
                                                .foregroundColor(.primary)
                                        }
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        .padding(.horizontal)
                        
                        // MARK: - Description
                        List {
                            VStack(spacing: 8) {
                                HStack {
                                    Text("Description:")
                                        .foregroundColor(.primary)
                                    Spacer()
                                }
                                Text(movie.description)
                                    .foregroundColor(.secondary)
                                    .font(.body)
                            }
                            .listRowBackground(Color.clear)
                            .ignoresSafeArea()
                        }
                            .font(.title3)
                            .listStyle(.insetGrouped)
                            .scrollContentBackground(.hidden)
                            .shadow(color: .secondary, radius: 5, x: 5, y: 5)
                            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    }
                    .padding(.top, UIScreen.main.bounds.height/6)
                }
                
                HStack {
                    // MARK: - Favorites Button
                    Button {
                        var arr = isInFavorites
                        if arr.contains(movie.id) {
                        arr = arr.filter { $0 != movie.id }
                            UserDefaults.standard.set(arr, forKey: "favorites")
                            isInFavorites = arr
                        } else {
                            arr.append(movie.id)
                            UserDefaults.standard.set(arr, forKey: "favorites")
                            isInFavorites = arr
                        }
                        withAnimation(.spring(response: 0.9,dampingFraction: 0.1,blendDuration: 0)){
                            animationHeart.toggle()
                        }
                    } label: {
                        Image(systemName: isInFavorites.contains(movie.id) ? "heart.fill" : "heart")
                            .font(.largeTitle)
                            .foregroundColor(.pink)
                            .scaleEffect(animationHeart ? 1.5 : 1.0)
                    }
 
                    // MARK: - Navigation
                    NavigationLink(destination: BookingPage(movie: movie)) {
                        Label("Choose Seats", systemImage: "ticket.fill")
                            .font(.title)
                            .foregroundColor(.white)
                            .bold()
                            .padding()
                            .background(.orange, in: RoundedRectangle(cornerRadius: 20))
                    }
                }
                
            }
        }
    }
}

//struct MovieDetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        MovieDetailsView(movie: Movie.movies.first!)
//    }
//}
