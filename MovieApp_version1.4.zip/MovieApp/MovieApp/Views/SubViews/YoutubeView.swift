//
//  YoutubeView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import SwiftUI
import YouTubePlayerKit

struct YoutubeView: View {
    @Binding var isPresented: Bool
    var youTubePlayer: YouTubePlayer
    var body: some View {
        ZStack {
            LinearGradient(colors: [.gray , .black], startPoint: .leading, endPoint: .trailing)
            VStack{
                
                YouTubePlayerView(self.youTubePlayer) { state in
                    // Overlay ViewBuilder closure to place an overlay View
                    // for the current `YouTubePlayer.State`
                    switch state {
                    case .idle:
                        ProgressView()
                    case .ready:
                        EmptyView()
                    case .error:
                        Text(verbatim: "YouTube player couldn't be loaded")
                    }
                }
                
                Button{
                    isPresented = false
                }label: {
                    Image(systemName: "x.circle")
                        .font(.title)
                        .foregroundColor(.red)
                        .padding()
                        .background(.regularMaterial , in: Circle())
                } .padding()
            }
            
        }
    }
}
