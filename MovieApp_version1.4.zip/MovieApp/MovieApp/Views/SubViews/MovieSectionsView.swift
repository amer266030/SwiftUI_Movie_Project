//
//  MovieSectionsView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 26/01/2023.
//

import SwiftUI

struct MovieSectionsView: View {
    var status: String
    var movie: Movie
    var body: some View {
        VStack {
            movie.poster
                .resizable()
                .aspectRatio(contentMode: .fit)
                .mask(RoundedRectangle(cornerRadius: 20))
                .frame(width: UIScreen.main.bounds.width/1.4)

            Text(movie.title)
                .font(.title3)
                .foregroundColor(.primary)
                .bold()
            
            HStack {
                ForEach(movie.genre, id: \.self) { genre in
                    Text(genre.rawValue)
                        .foregroundColor(.black)
                        .padding(8)
                        .background(.orange, in: Capsule())
                }
            }
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
