//
//  MainTab_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension MainTabView {
    var movieK: String {
       let format = NSLocalizedString("movieL", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var ticketK: String {
       let format = NSLocalizedString("ticketL", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var ProfileK: String {
       let format = NSLocalizedString("ProfileL", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var FavoritesK: String {
       let format = NSLocalizedString("favoritesK", comment:"")
       return String.localizedStringWithFormat(format)
    }
}
