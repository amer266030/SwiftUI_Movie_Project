//
//  ProfileView_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension ProfileView {
    var AbdullahK: String {
       let format = NSLocalizedString("AbdullahL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SettingsK: String {
       let format = NSLocalizedString("SettingsL", comment: "")
       return String.localizedStringWithFormat(format)
    }
  
    var   LanguageK: String {
       let format = NSLocalizedString("  LanguageL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var   NotificationsK: String {
       let format = NSLocalizedString("  NotificationsL", comment: "")
       return String.localizedStringWithFormat(format)
    }
  
    var    DarkModeK: String {
       let format = NSLocalizedString(" DarkModeL", comment: "")
       return String.localizedStringWithFormat(format)
    }
   
    var    SoundK: String {
       let format = NSLocalizedString("  SoundL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var   SignOutK: String {
       let format = NSLocalizedString("  SignOutL", comment: "")
       return String.localizedStringWithFormat(format)
    }
}
