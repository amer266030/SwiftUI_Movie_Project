//
//  BookedTickets_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension ReservedTicketsView {
    var bookedTicketsK: String {
       // know key
       let format = NSLocalizedString("bookedTicketsK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var viewTicketK: String {
       // know key
       let format = NSLocalizedString("viewTicketK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    
}
