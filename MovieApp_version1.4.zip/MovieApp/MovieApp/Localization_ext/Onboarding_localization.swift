//
//  Onboarding_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension OnboardingView {
    var  PopcornMoviesK: String {
       let format = NSLocalizedString("  PopcornMoviesL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var  WelcomePopcornK: String {
       let format = NSLocalizedString("  WelcomePopcornL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SearchK: String {
       let format = NSLocalizedString(" SearchL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var LookFavoriteK: String {
       let format = NSLocalizedString(" LookFavoriteL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var FavoriteK: String {
       let format = NSLocalizedString(" FavoriteL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var convenienceK: String {
       let format = NSLocalizedString("  convenienceL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var NotificationsK: String {
       let format = NSLocalizedString("  NotificationsL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SetupremindersK: String {
       let format = NSLocalizedString("  SetupremindersL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var EnjoyK: String {
       let format = NSLocalizedString("  EnjoyL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var PopcornK: String {
       let format = NSLocalizedString(" PopcornL", comment: "")
       return String.localizedStringWithFormat(format)
    }
}
