//
//  SearchCriteria_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension SearchCriteriaView {
    var titleK: String {
       // know key
       let format = NSLocalizedString("titleK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var genreK: String {
       // know key
       let format = NSLocalizedString("genreK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    
}
