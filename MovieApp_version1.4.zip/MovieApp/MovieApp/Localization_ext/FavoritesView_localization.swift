//
//  FavoritesView_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 29/01/2023.
//

import Foundation

extension FavoriteView {
    var favoritesK: String {
       // know key
       let format = NSLocalizedString("favoritesK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var shareMovieK: String {
       // know key
       let format = NSLocalizedString("shareMovieK", comment:"")
       return String.localizedStringWithFormat(format)
    }
    
}
